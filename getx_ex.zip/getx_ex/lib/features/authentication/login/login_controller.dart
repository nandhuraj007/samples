import 'package:get/get.dart';

import '../authentication_controller.dart';
import '../authentication_service.dart';
import 'login_state.dart';


class LoginController  extends GetxController {
  final AuthenticationController _authenticationController = Get.find();

  final _loginStateStream = LoginState().obs;

  LoginState get state => _loginStateStream.value;

  void login(String email, String password, String age, String phone) async {
    _loginStateStream.value = LoginLoading();

    try{
      await _authenticationController.signIn(email,password,age, phone);
     // await _authenticationController.signIn(email, password);
      _loginStateStream.value = LoginState();
    } on AuthenticationException catch(e){
      _loginStateStream.value = LoginFailure(error: e.message);
    }
  }
}