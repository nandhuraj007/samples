package com.example.getx_ex

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
