// import 'package:flutter/material.dart';
// import 'package:url_launcher/url_launcher.dart';
//
// void main() {
//   runApp(const MyApp());
// }
//
// class MyApp extends StatelessWidget {
//   const MyApp({super.key});
//
//   // This widget is the root of your application.
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       title: 'Flutter Demo',
//       theme: ThemeData(
//         // This is the theme of your application.
//         //
//         // Try running your application with "flutter run". You'll see the
//         // application has a blue toolbar. Then, without quitting the app, try
//         // changing the primarySwatch below to Colors.green and then invoke
//         // "hot reload" (press "r" in the console where you ran "flutter run",
//         // or simply save your changes to "hot reload" in a Flutter IDE).
//         // Notice that the counter didn't reset back to zero; the application
//         // is not restarted.
//         primarySwatch: Colors.blue,
//       ),
//       home: const MyHomePage(title: 'Flutter Demo Home Page'),
//     );
//   }
// }
//
// class MyHomePage extends StatefulWidget {
//   const MyHomePage({super.key, required this.title});
//
//   // This widget is the home page of your application. It is stateful, meaning
//   // that it has a State object (defined below) that contains fields that affect
//   // how it looks.
//
//   // This class is the configuration for the state. It holds the values (in this
//   // case the title) provided by the parent (in this case the App widget) and
//   // used by the build method of the State. Fields in a Widget subclass are
//   // always marked "final".
//
//   final String title;
//
//   @override
//   State<MyHomePage> createState() => _MyHomePageState();
// }
//
// class _MyHomePageState extends State<MyHomePage> {
//   final Uri _url = Uri.parse('https://flutter.dev');
//
//
//   @override
//   Widget build(BuildContext context) {
//     // This method is rerun every time setState is called, for instance as done
//     // by the _incrementCounter method above.
//     //
//     // The Flutter framework has been optimized to make rerunning build methods
//     // fast, so that you can just rebuild anything that needs updating rather
//     // than having to individually change instances of widgets.
//     return Scaffold(
//       appBar: AppBar(
//         // Here we take the value from the MyHomePage object that was created by
//         // the App.build method, and use it to set our appbar title.
//         title: Text(widget.title),
//       ),
//       body: Center(
//         // Center is a layout widget. It takes a single child and positions it
//         // in the middle of the parent.
//         child: Column(
//           children: [
//
//           ElevatedButton(
//           onPressed: _launchUrl,
//           child: Text('Show Flutter homepage'),
//         ),
//             ElevatedButton(onPressed: ,
//                 child: Text("compose Email")
//             ),
//             ElevatedButton(onPressed: ,
//                 child: Text(" call")
//             ),
//
//           ],
//       ), // This trailing comma makes auto-formatting nicer for build methods.
//     ),
//     );
//
//   }
//
//   _launchURLApp() async {
//     if (await canLaunchUrl(_url)) {
// await launchUrl(_url);
//
//     } else {
//       throw 'Could not launch $_url';
//     }
//   }
//
// }

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:url_launcher/link.dart';
import 'package:url_launcher/url_launcher.dart';
import 'HomePage.dart';
import 'forCall.dart';
import 'forEmail.dart';
import 'forSms.dart';
import 'forWebsite.dart';
import 'package:url_launcher/url_launcher.dart';
import 'forCall.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'URL Launcher',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),

      home: const homePage(),
      routes: {
        '/calls': (context) => const ForCall(),
        '/sms': (context) => const ForSMS(),
        '/mails': (context) => const ForWmail(),
        '/webs': (context) => const ForWebsite()
      },
    );
  }
}

// class MyHomePage extends StatefulWidget {
//   MyHomePage({Key? key, required this.title}) : super(key: key);
//   final String title;
//
//   @override
//   _MyHomePageState createState() => _MyHomePageState();
// }
//
// class _MyHomePageState extends State<MyHomePage> {
//   Future<void>? _launched;
//   String _phone = '';
//
//   Future<void> _launchInBrowser(String url) async {
//     if (await canLaunch(url)) {
//       await launch(
//         url,
//         forceSafariVC: false,
//         forceWebView: false,
//         headers: <String, String>{'my_header_key': 'my_header_value'},
//       );
//     } else {
//       throw 'Could not launch $url';
//     }
//   }
//
//   Future<void> _launchInWebViewOrVC(String url) async {
//     if (await canLaunch(url)) {
//       await launch(
//         url,
//         forceSafariVC: true,
//         forceWebView: true,
//         headers: <String, String>{'my_header_key': 'my_header_value'},
//       );
//     } else {
//       throw 'Could not launch $url';
//     }
//   }
//
//   Future<void> _launchInWebViewWithJavaScript(String url) async {
//     if (await canLaunch(url)) {
//       await launch(
//         url,
//         forceSafariVC: true,
//         forceWebView: true,
//         enableJavaScript: true,
//       );
//     } else {
//       throw 'Could not launch $url';
//     }
//   }
//
//   Future<void> _launchInWebViewWithDomStorage(String url) async {
//     if (await canLaunch(url)) {
//       await launch(
//         url,
//         forceSafariVC: true,
//         forceWebView: true,
//         enableDomStorage: true,
//       );
//     } else {
//       throw 'Could not launch $url';
//     }
//   }
//
//   Future<void> _launchUniversalLinkIos(String url) async {
//     if (await canLaunch(url)) {
//       final bool nativeAppLaunchSucceeded = await launch(
//         url,
//         forceSafariVC: false,
//         universalLinksOnly: true,
//       );
//       if (!nativeAppLaunchSucceeded) {
//         await launch(
//           url,
//           forceSafariVC: true,
//         );
//       }
//     }
//   }
//
//   Widget _launchStatus(BuildContext context, AsyncSnapshot<void> snapshot) {
//     if (snapshot.hasError) {
//       return Text('Error: ${snapshot.error}');
//     } else {
//       return const Text('');
//     }
//   }
//
//   Future<void> _makePhoneCall(String url) async {
//     if (await canLaunch(url)) {
//       await launch(url);
//     } else {
//       throw 'Could not launch $url';
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     const String toLaunch = 'https://www.cylog.org/headers/';
//     return Scaffold(
//       appBar: AppBar(
//         title: Text(widget.title),
//       ),
//       body: ListView(
//         children: <Widget>[
//           Column(
//             mainAxisAlignment: MainAxisAlignment.center,
//             children: <Widget>[
//               Padding(
//                 padding: const EdgeInsets.all(16.0),
//                 child: TextField(
//                     onChanged: (String text) => _phone = text,
//                     decoration: const InputDecoration(
//                         hintText: 'Input the phone number to launch')),
//               ),
//               ElevatedButton(
//                 onPressed: () => setState(() {
//                   _launched = _makePhoneCall('tel:$_phone');
//                 }),
//                 child: const Text('Make phone call'),
//               ),
//               const Padding(
//                 padding: EdgeInsets.all(16.0),
//                 child: Text(toLaunch),
//               ),
//               ElevatedButton(
//                 onPressed: () => setState(() {
//                   _launched = _launchInBrowser(toLaunch);
//                 }),
//                 child: const Text('Launch in browser'),
//               ),
//               const Padding(padding: EdgeInsets.all(16.0)),
//               ElevatedButton(
//                 onPressed: () => setState(() {
//                   _launched = _launchInWebViewOrVC(toLaunch);
//                 }),
//                 child: const Text('Launch in app'),
//               ),
//               ElevatedButton(
//                 onPressed: () => setState(() {
//                   _launched = _launchInWebViewWithJavaScript(toLaunch);
//                 }),
//                 child: const Text('Launch in app(JavaScript ON)'),
//               ),
//               ElevatedButton(
//                 onPressed: () => setState(() {
//                   _launched = _launchInWebViewWithDomStorage(toLaunch);
//                 }),
//                 child: const Text('Launch in app(DOM storage ON)'),
//               ),
//               const Padding(padding: EdgeInsets.all(16.0)),
//               ElevatedButton(
//                 onPressed: () => setState(() {
//                   _launched = _launchUniversalLinkIos(toLaunch);
//                 }),
//                 child: const Text(
//                     'Launch a universal link in a native app, fallback to Safari.(Youtube)'),
//               ),
//               const Padding(padding: EdgeInsets.all(16.0)),
//               ElevatedButton(
//                 onPressed: () => setState(() {
//                   _launched = _launchInWebViewOrVC(toLaunch);
//                   Timer(const Duration(seconds: 5), () {
//                     print('Closing WebView after 5 seconds...');
//                     closeWebView();
//                   });
//                 }),
//                 child: const Text('Launch in app + close after 5 seconds'),
//               ),
//               const Padding(padding: EdgeInsets.all(16.0)),
//               Link(
//                 uri: Uri.parse(
//                     'https://pub.dev/documentation/url_launcher/latest/link/link-library.html'),
//                 target: LinkTarget.blank,
//                 builder: (ctx, openLink) {
//                   return TextButton.icon(
//                     onPressed: openLink,
//                     label: Text('Link Widget documentation'),
//                     icon: Icon(Icons.read_more),
//                   );
//                 },
//               ),
//               const Padding(padding: EdgeInsets.all(16.0)),
//               FutureBuilder<void>(future: _launched, builder: _launchStatus),
//             ],
//           ),
//         ],
//       ),
//     );
//   }
// }