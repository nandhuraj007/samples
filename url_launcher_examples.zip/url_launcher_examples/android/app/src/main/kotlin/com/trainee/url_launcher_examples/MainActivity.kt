package com.trainee.url_launcher_examples

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
