package com.geograf.geograf

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
