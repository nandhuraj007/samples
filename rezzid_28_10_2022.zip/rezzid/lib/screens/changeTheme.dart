import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../model_theme.dart';
class ThemePage extends StatefulWidget {
  const ThemePage({Key? key}) : super(key: key);
  @override
  ThemePageState createState() => ThemePageState();
}
class ThemePageState extends State<ThemePage> {
  @override
  Widget build(BuildContext context) {
    return Consumer<ModelTheme>(
        builder: (context, ModelTheme themeNotifier, child) {
          return Scaffold(
            appBar: AppBar(
            ),
            body:
            Center(
              child: SizedBox(
                width: 300.0,
                height: 50,
                child: ElevatedButton(
                    child: const Text("Change Theme"),
                    onPressed: () {
                      themeNotifier.isDark
                          ? themeNotifier.isDark = false
                          : themeNotifier.isDark = true;
                    }
                ),
              ),
            ),
            );
        });
  }
}