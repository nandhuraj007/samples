import 'package:flutter/material.dart';
class NewGroups extends StatefulWidget {
  const NewGroups({Key? key}) : super(key: key);

  @override
  State<NewGroups> createState() => _NewGroupsState();
}

class _NewGroupsState extends State<NewGroups> {
  @override
  Widget build(BuildContext context) {
    return
      Scaffold(
        appBar: AppBar(

        ),
      );
  }
}
