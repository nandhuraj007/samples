package com.assignment.assignment

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
