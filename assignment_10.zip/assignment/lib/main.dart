
import 'package:flutter/material.dart';
import 'Module2Part2/Part3/CustomFloatingActionButtons.dart';
import 'Module2Part2/Part3/rowAndColumn/stackPage.dart';
import 'Module3Part2/Part2/loginPageAndSignUp/welcomeScreen.dart';
import 'home.dart';
void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
        theme: ThemeData.dark(),
        home:   mainHome()
    );
  }
}


