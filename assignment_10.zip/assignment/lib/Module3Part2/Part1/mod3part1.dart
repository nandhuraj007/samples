import 'package:flutter/material.dart';

import '../../homeConstants.dart';
import 'DropDownButton.dart';
import 'bottumSheet.dart';

class module3part1Home extends StatefulWidget {
  const module3part1Home({Key? key}) : super(key: key);

  @override
  State<module3part1Home> createState() => _module3part1HomeState();
}
class _module3part1HomeState extends State<module3part1Home> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
      ),
      body: Column(
        children: [
          SizedBox(
            height: 150,
          ),
          GradientButton(
              onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>DropDown()));
              },
              child: Text("Question 1")),
          SizedBox(height: 10),
          GradientButton(
              onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>ModalBottomSheet()));
              },
              child: Text("Question 2")),
          SizedBox(height: 10),

        ],
      ),
    );
  }
}
