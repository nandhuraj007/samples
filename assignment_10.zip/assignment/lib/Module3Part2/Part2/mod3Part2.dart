import 'package:assignment/Module3Part2/Part2/silvergridmaker.dart';
import 'package:assignment/Module3Part2/Part2/wedgettrees.dart';
import 'package:flutter/material.dart';

import '../../homeConstants.dart';
import 'loginPageAndSignUp/welcomeScreen.dart';

class module3part2Home extends StatefulWidget {
  const module3part2Home({Key? key}) : super(key: key);

  @override
  State<module3part2Home> createState() => _module3part2HomeState();
}
class _module3part2HomeState extends State<module3part2Home> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
      ),
      body: Column(
        children: [
          SizedBox(
            height: 150,
          ),
          GradientButton(
              onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>WelcomeScreen()));
              },
              child: Text("Question 1")),
          SizedBox(height: 10),
          GradientButton(
              onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>CollapsingList()));
              },
              child: Text("Question 2")),
          SizedBox(height: 10),
          GradientButton(
              onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>wedgettree11()));
              },
              child: Text("Question 3")),
          SizedBox(height: 10),

        ],
      ),
    );
  }
}
