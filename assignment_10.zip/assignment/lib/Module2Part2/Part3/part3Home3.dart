import 'package:assignment/Module2Part2/Part3/rowAndColumn/stackPage.dart';
import 'package:flutter/material.dart';

import '../../homeConstants.dart';
import 'CustomFloatingActionButtons.dart';
import 'containers.dart';

class part3homeEx extends StatefulWidget {
  const part3homeEx({Key? key}) : super(key: key);

  @override
  State<part3homeEx> createState() => _part3homeExState();
}

class _part3homeExState extends State<part3homeEx> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
      ),
      body: Column(
        children: [
          SizedBox(
            height: 150,
          ),
          GradientButton(
              onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>MyContainer()));
              },
              child: Text("Question 1")),
          SizedBox(height: 10),
          GradientButton(
              onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>Cfab()));
              },
              child: Text("Question 2")),
          SizedBox(height: 10),
          GradientButton(
              onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>StackPage()));
              },
              child: Text("Question 3")),
          SizedBox(height: 10),
        ],
      ),
    );
  }
}
