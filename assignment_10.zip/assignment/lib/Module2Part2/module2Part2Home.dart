import 'package:flutter/material.dart';
import '../homeConstants.dart';
import 'Part1/WedgetTree/wedgetTreeEx.dart';
import 'Part2/part2Home1.dart';
import 'Part3/part3Home3.dart';
import 'Part4/part4Home4.dart';
import 'Part5/part5Home5.dart';
class module2part2Home extends StatefulWidget {
  const module2part2Home({Key? key}) : super(key: key);

  @override
  State<module2part2Home> createState() => _module2part2HomeState();
}
class _module2part2HomeState extends State<module2part2Home> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
      ),
      body: Column(
        children: [
          SizedBox(
            height: 150,
          ),
          GradientButton(
              onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>wedgettree()));
              },
              child: Text("Part 1")),
          SizedBox(height: 10),
          GradientButton(
              onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>part2homeEx()));
              },
              child: Text("Part 2")),
          SizedBox(height: 10),
          GradientButton(
              onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>part3homeEx()));
              },
              child: Text("Part 3")),
          SizedBox(height: 10),
          GradientButton(
              onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>part4homeEx()));
              },
              child: Text("Part 4")),
          SizedBox(height: 10),
          GradientButton(
              onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>part5homeEx()));
              },
              child: Text("Part 5")),
          SizedBox(height: 10),
        ],
      ),
    );
  }
}
