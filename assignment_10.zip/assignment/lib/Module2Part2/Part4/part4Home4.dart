import 'package:assignment/Module2Part2/Part3/rowAndColumn/stackPage.dart';
import 'package:assignment/Module2Part2/Part4/registratonPage.dart';
import 'package:flutter/material.dart';
import '../../homeConstants.dart';
import 'CheckBox/home.dart';
import 'loginPage.dart';
class part4homeEx extends StatefulWidget {
  const part4homeEx({Key? key}) : super(key: key);

  @override
  State<part4homeEx> createState() => _part4homeExState();
}

class _part4homeExState extends State<part4homeEx> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
      ),
      body: Column(
        children: [
          SizedBox(
            height: 150,
          ),
          GradientButton(
              onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>SignUpPage()));
              },
              child: Text("Question 1")),
          SizedBox(height: 10),
          GradientButton(
              onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>LoginPage()));
              },
              child: Text("Question 2")),
          SizedBox(height: 10),
          GradientButton(
              onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>Myboy()));
              },
              child: Text("Question 3")),
          SizedBox(height: 10),
        ],
      ),
    );
  }
}
