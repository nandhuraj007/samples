import 'package:flutter/material.dart';

import '../../homeConstants.dart';
import 'FAB1.dart';
import 'FAB2.dart';
import 'containerText.dart';
class part2homeEx extends StatefulWidget {
  const part2homeEx({Key? key}) : super(key: key);

  @override
  State<part2homeEx> createState() => _part2homeExState();
}

class _part2homeExState extends State<part2homeEx> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
      ),
      body: Column(
        children: [
          SizedBox(
            height: 150,
          ),
          GradientButton(
              onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>ContainerEx()));
              },
              child: Text("Question 1")),
          SizedBox(height: 10),
          GradientButton(
              onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>fab1()));
              },
              child: Text("Question 2")),
          SizedBox(height: 10),
          GradientButton(
              onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>fab2()));
              },
              child: Text("Question 3")),
          SizedBox(height: 10),
        ],
      ),
    );
  }
}
