import 'package:flutter/material.dart';
import '../../homeConstants.dart';
import 'CustomAlertBox.dart';
import 'ImageView.dart';
import 'alertBox2.dart';
class part5homeEx extends StatefulWidget {
  const part5homeEx({Key? key}) : super(key: key);

  @override
  State<part5homeEx> createState() => _part5homeExState();
}

class _part5homeExState extends State<part5homeEx> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
      ),
      body: Column(
        children: [
          SizedBox(
            height: 150,
          ),
          GradientButton(
              onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>AlertBox1()));
              },
              child: Text("Question 1")),
          SizedBox(height: 10),
          GradientButton(
              onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>MyAlert()));
              },
              child: Text("Question 2")),
          SizedBox(height: 10),
          GradientButton(
              onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>ImageViews()));
              },
              child: Text("Question 3")),
          SizedBox(height: 10),
        ],
      ),
    );
  }
}
