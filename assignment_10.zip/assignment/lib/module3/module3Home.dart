import 'package:assignment/homeConstants.dart';
import 'package:assignment/module3/sharedPreference/homePage.dart';
import 'package:assignment/module3/splashScreen/splashScreens.dart';
import 'package:assignment/module3/textTospeech/textToSpeechEx.dart';
import 'package:assignment/module3/whether/view/location_screens.dart';
import 'package:flutter/material.dart';
import 'alarm/alarmEx.dart';
import 'googleMap/googleMapHome.dart';
class module3HomePage extends StatelessWidget {
  const module3HomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(

      ),
      body: Column(
        children:  [
          SizedBox(
            height: 150,
          ),
          GradientButton(
              onPressed: (){
            Navigator.push(context, MaterialPageRoute(builder: (context)=>AlarmPage()));
          },
              child: Text("Alarm App")),
          SizedBox(height: 10),
          GradientButton(
              onPressed: (){
            Navigator.push(context, MaterialPageRoute(builder: (context)=>mapHome()));
          },
              child: Text("Google Map App")),
          SizedBox(height: 10),
          GradientButton(
              onPressed: (){
            Navigator.push(context, MaterialPageRoute(builder: (context)=>HomePageExample()));
          },
              child: Text("Login Page Shared Preference")),
          SizedBox(height: 10),
          GradientButton(
              onPressed: (){
            Navigator.push(context, MaterialPageRoute(builder: (context)=>SplashScreenPage()));
          },
              child: Text("Splash Screen")),
          SizedBox(height: 10),
          GradientButton(
              onPressed: (){
            Navigator.push(context, MaterialPageRoute(builder: (context)=>TextToSpeech()));
          },
              child: Text("Text To Speech")),
          SizedBox(height: 10),
          GradientButton(
              onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>LocationScreen()));
          },
              child: Text("Whether App")),
        ],
      ),
    );
  }
}

