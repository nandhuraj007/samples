import 'package:assignment/module2/urlLauncher/screens/forCall.dart';
import 'package:assignment/module2/urlLauncher/screens/forEmail.dart';
import 'package:assignment/module2/urlLauncher/screens/forSms.dart';
import 'package:assignment/module2/urlLauncher/screens/forWebsite.dart';
import 'package:flutter/material.dart';
class urlHomes extends StatefulWidget {
  const urlHomes({Key? key}) : super(key: key);

  @override
  State<urlHomes> createState() => _urlHomesState();
}

class _urlHomesState extends State<urlHomes> {
  var selectedItem = '';
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(""),
        centerTitle: true,
        actions: [
          PopupMenuButton( onSelected: (result)
        {
          if(result==0){
            Navigator.push(context, MaterialPageRoute(builder: (context)=>ForCall()));
          }
          if(result==1){
            Navigator.push(context, MaterialPageRoute(builder: (context)=>ForSMS()));
          }
          if(result==2){
            Navigator.push(context, MaterialPageRoute(builder: (context)=>ForWmail()));
          }
          if(result==3){
            Navigator.push(context, MaterialPageRoute(builder: (context)=>ForWebsite()));
          }


        },
              itemBuilder: (BuildContext bc) {
            return  [
              PopupMenuItem(
                child: Text("Call"),
                value: 0,
              ),
              PopupMenuItem(
                child: Text("Sms"),
                value: 1,
              ),
              PopupMenuItem(
                child: Text("Mail"),
                value: 2,
              ),
              PopupMenuItem(
                child: Text("web"),
                value: 3,
              )
            ];
          })
        ],
      ),
      body: Center(
        child: Text(selectedItem),
      ),
    );
  }
}
