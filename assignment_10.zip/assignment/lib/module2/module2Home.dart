import 'package:assignment/module2/quiz/quizHome.dart';
import 'package:assignment/module2/sqlFliteCrud/mainPage.dart';
import 'package:assignment/module2/toDo/toDoHome.dart';
import 'package:assignment/module2/urlLauncher/urlHome.dart';
import 'package:flutter/material.dart';

import '../homeConstants.dart';
import 'calculator/screens/calculatorPage.dart';
import 'flashLight/mainHome.dart';
class module2HomePage extends StatefulWidget {
  const module2HomePage({Key? key}) : super(key: key);

  @override
  State<module2HomePage> createState() => _module2HomePageState();
}

class _module2HomePageState extends State<module2HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
      ),
      body: Column(
        children: [
          SizedBox(
            height: 150,
          ),
          GradientButton(
              onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>calculatorHomePage()));
              },
              child: Text("Calculator")),
          SizedBox(height: 10),
          GradientButton(
              onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>MyHomePage()));
              },
              child: Text("Flash Light")),
          SizedBox(height: 10),
          GradientButton(
              onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>quizHomes()));
              },
              child: Text("Quiz App")),
          SizedBox(height: 10),
          GradientButton(
              onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>crudHome()));
              },
              child: Text("CRUD operations")),
          SizedBox(height: 10),
          GradientButton(
              onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>TodoApp()));
              },
              child: Text("To Do App")),
          SizedBox(height: 10),
          GradientButton(
              onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>urlHomes()));
              },
              child: Text("URL Launcher")),
          SizedBox(height: 10),
          GradientButton(
              onPressed: (){

              },
              child: Text("Video Audio Rcorder")),
        ],
      ),
    );
  }
}
